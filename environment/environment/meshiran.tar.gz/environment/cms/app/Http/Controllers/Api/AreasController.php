<?php

namespace App\Http\Controllers\Api;

use App\Area;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class AreasController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
   public function index()
    {
         $areas = Area::all();
         return $areas;
    }


public function store(Request $request)
    {
        

        $area = new Area;
        $area->country_id = $request->country_id;
        $area->prefecture_id = $request->prefecture_id;
        $area->district_id = $request->district_id;
        $area->save();  
    }
    
    
public function show(Area $area)
    {
         return $area;
    }
    
public function update(Request $request, Area $area)
    {
        $area = new Area;
        $area->country_id = $request->country_id;
        $area->prefecture_id = $request->prefecture_id;
        $area->district_id = $request->district_id;
        $area->save();  
        return $area;
    }
    
public function destroy(Area $area)
    {
         $area->delete();
    }
}
