<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\User;
use App\Area;
use Auth;//この行を上に追加
use Validator;//この行を上に追
use Illuminate\Http\Request;

class UsersController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $users = User::all();
        return $users;
    }

    public function store(Request $request)
    {
        $user = new User;
        $user->$request->id;
        $user->name =$request->name;
        $user->profile_image_url = $request->profile_image_url;
        $user->birthday = $request->birthday;
        $user->sex = $request->sex;
        $user->email = $request->email;
        $user->password = $request->password; 
        $user->area_id = $request-> area_id;
        $user->profile_text = $request-> profile_text;
        $user->save();  
    }
    
public function show(User $user)
    {
        return $user;
    }
    
public function update(Request $request, User $user)
    {
        $user = new User;
        $user->$request->id;
        $user->name =$request->name;
        $user->profile_image_url = $request->profile_image_url;
        $user->birthday = $request->birthday;
        $user->sex = $request->sex;
        $user->email = $request->email;
        $user->password = $request->password; 
        $user->area_id = $request-> area_id;
        $user->profile_text = $request-> profile_text;
        $user->save();  
        return $user;
    }
    
public function destroy(User $user)
    {
        $user->delete();
    }

}
