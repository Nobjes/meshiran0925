<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Area extends Model
{
    // Areaに対して、複数のUsersが存在する（Areasが主テーブル）
    public function users() {
      	  return $this->hasMany('App\User');
   }
   
   
   //Restaurantsテーブルとのリレーション　Areaは複数のRestaurantに紐づく （主テーブル側）
    public function restaurants () {
       return $this->hasMany('App\Restaurant');
 }   
 
 
 //Mapsテーブルとのリレーション　AreaはひとつのMAPに紐づく （主テーブル側）
    public function map () {
       return $this->hasOne('App\Map');
 } 




}
